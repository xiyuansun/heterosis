heterosis_mcmc = function(){
  dyn.load(paste(.libPaths(), "/heterosis/libs/heterosis.so"))
}

gpu_heterosis_mcmc = function(){
  dyn.load(paste(.libPaths(), "/heterosis/libs/heterosis.so"))
}