heterosis_mcmc = function(){
  dyn.load(paste(.libPaths(), "/heterosis/libs/heterosis.so"))
}