system("../make")
__HETEROSIS_ROOT__ = getwd()