HETEROSIS_ROOT = getwd()
system("make")