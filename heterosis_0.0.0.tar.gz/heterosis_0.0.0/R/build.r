print(getwd())
#system("../make")