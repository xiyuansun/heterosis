write(getwd(), "ROOT")
system("make")